import os
import json


def handle_incoming_message(body_json, context):
    print(body_json['Message'])
    print(context)
